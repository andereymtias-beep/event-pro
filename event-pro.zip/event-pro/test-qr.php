﻿<?php
require __DIR__ . '/vendor/autoload.php';
require __DIR__ . '/includes/functions.php';

try {
    generateQrCode(
        'EVENT-PRO-TEST-TOKEN',
        __DIR__ . '/storage/qrcodes/debug-qr.png'
    );
    echo "SUCCESS: QR generated";
} catch (Throwable $e) {
    echo "ERROR: " . get_class($e) . ": " . $e->getMessage();
}
