
<?php
require_once __DIR__ . '/config/database.php';

echo 'Success! Event-Pro is connected to MySQL.';
