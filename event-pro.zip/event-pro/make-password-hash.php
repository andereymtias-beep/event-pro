﻿<?php
$password = 'ChangeMe!2026-EventPro';
$hash = password_hash($password, PASSWORD_DEFAULT);

echo 'Length: ' . strlen($hash) . PHP_EOL;
echo 'Valid: ' . (password_verify($password, $hash) ? 'YES' : 'NO') . PHP_EOL;
echo 'Hash: ' . $hash . PHP_EOL;
