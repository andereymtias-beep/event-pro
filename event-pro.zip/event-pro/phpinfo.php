
<?php
phpinfo();
