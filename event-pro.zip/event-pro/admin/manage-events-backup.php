
<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../includes/auth.php';
require_once __DIR__ . '/../includes/csrf.php';

requireStaffLogin();

if (currentStaffRole() !== 'admin') {
    http_response_code(403);
    exit('Access denied.');
}

$message = '';
$messageType = 'success';

$title = '';
$description = '';
$eventDate = '';
$startTime = '';
$endTime = '';
$venue = '';
$organizer = '';
$maxAttendees = '100';
$registrationOpen = '1';
$isActive = '1';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $submittedToken = $_POST['csrf_token'] ?? null;

    if (!verifyCsrfToken(
        is_string($submittedToken) ? $submittedToken : null
    )) {
        http_response_code(403);
        exit('Invalid or expired security token. Refresh the page and try again.');
    }

    $title = trim($_POST['title'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $eventDate = trim($_POST['event_date'] ?? '');
    $startTime = trim($_POST['start_time'] ?? '');
    $endTime = trim($_POST['end_time'] ?? '');
    $venue = trim($_POST['venue'] ?? '');
    $organizer = trim($_POST['organizer'] ?? '');
    $maxAttendees = trim($_POST['max_attendees'] ?? '');
    $registrationOpen = $_POST['registration_open'] ?? '1';
    $isActive = $_POST['is_active'] ?? '1';

    $capacity = filter_var($maxAttendees, FILTER_VALIDATE_INT);

    if (
        $title === '' ||
        $eventDate === '' ||
        $startTime === '' ||
        $endTime === '' ||
        $venue === '' ||
        $organizer === '' ||
        $capacity === false ||
        $capacity < 1
    ) {
        $message = 'Complete all required fields and enter a valid capacity.';
        $messageType = 'danger';
    } elseif (
        !in_array($registrationOpen, ['0', '1'], true) ||
        !in_array($isActive, ['0', '1'], true)
    ) {
        $message = 'Invalid event status selected.';
        $messageType = 'danger';
    } elseif (
        !preg_match('/^\d{4}-\d{2}-\d{2}$/', $eventDate) ||
        !checkdate(
            (int) substr($eventDate, 5, 2),
            (int) substr($eventDate, 8, 2),
            (int) substr($eventDate, 0, 4)
        )
    ) {
        $message = 'Enter a valid event date.';
        $messageType = 'danger';
    } elseif (
        !preg_match('/^\d{2}:\d{2}$/', $startTime) ||
        !preg_match('/^\d{2}:\d{2}$/', $endTime) ||
        $startTime >= $endTime
    ) {
        $message = 'Enter valid times. The end time must be later than the start time.';
        $messageType = 'danger';
    } else {
        try {
            $insert = $pdo->prepare(
                'INSERT INTO events
                    (title, description, event_date, start_time, end_time,
                     venue, organizer, max_attendees, registration_open, is_active)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
            );

            $insert->execute([
                $title,
                $description !== '' ? $description : null,
                $eventDate,
                $startTime,
                $endTime,
                $venue,
                $organizer,
                $capacity,
                (int) $registrationOpen,
                (int) $isActive
            ]);

            logActivity(
                $pdo,
                'event_created',
                currentStaffId(),
                (int) $pdo->lastInsertId(),
                'Created event: ' . $title
            );

            $message = 'Event created successfully.';
            $title = '';
            $description = '';
            $eventDate = '';
            $startTime = '';
            $endTime = '';
            $venue = '';
            $organizer = '';
            $maxAttendees = '100';
            $registrationOpen = '1';
            $isActive = '1';
        } catch (PDOException $e) {
            error_log('Event creation failed: ' . $e->getMessage());
            $message = 'Could not create the event. Check the PHP error log for details.';
            $messageType = 'danger';
        }
    }
}

$events = $pdo->query(
    'SELECT id, title, event_date, start_time, end_time, venue,
            organizer, max_attendees, registration_open, is_active
     FROM events
     ORDER BY event_date DESC, id DESC'
)->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Manage Events | Event-Pro</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #f4f6f9; }
        .page-card { border: 0; border-radius: 12px; }
    </style>
</head>
<body>
<div class="container py-5">
    <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">
        <div>
            <h1 class="h2 mb-1">Manage Events</h1>
            <p class="text-muted mb-0">Create and view seminar events.</p>
        </div>
        <a href="../staff/dashboard.php" class="btn btn-outline-secondary">
            Back to Dashboard
        </a>
    </div>

    <?php if ($message !== ''): ?>
        <div class="alert alert-<?= e($messageType) ?>" role="alert">
            <?= e($message) ?>
        </div>
    <?php endif; ?>

    <div class="card page-card shadow-sm mb-4">
        <div class="card-header bg-white py-3">
            <h2 class="h5 mb-0">Create New Event</h2>
        </div>
        <div class="card-body p-4">
            <form method="post">
                <?= csrfField() ?>

                <div class="row g-3">
                    <div class="col-md-8">
                        <label for="title" class="form-label">Event Title *</label>
                        <input type="text" class="form-control" id="title"
                               name="title" maxlength="200"
                               value="<?= e($title) ?>" required>
                    </div>

                    <div class="col-md-4">
                        <label for="max_attendees" class="form-label">Maximum Attendees *</label>
                        <input type="number" class="form-control" id="max_attendees"
                               name="max_attendees" min="1"
                               value="<?= e($maxAttendees) ?>" required>
                    </div>

                    <div class="col-12">
                        <label for="description" class="form-label">Description</label>
                        <textarea class="form-control" id="description"
                                  name="description" rows="3"><?= e($description) ?></textarea>
                    </div>

                    <div class="col-md-4">
                        <label for="event_date" class="form-label">Event Date *</label>
                        <input type="date" class="form-control" id="event_date"
                               name="event_date" value="<?= e($eventDate) ?>" required>
                    </div>

                    <div class="col-md-4">
                        <label for="start_time" class="form-label">Start Time *</label>
                        <input type="time" class="form-control" id="start_time"
                               name="start_time" value="<?= e($startTime) ?>" required>
                    </div>

                    <div class="col-md-4">
                        <label for="end_time" class="form-label">End Time *</label>
                        <input type="time" class="form-control" id="end_time"
                               name="end_time" value="<?= e($endTime) ?>" required>
                    </div>

                    <div class="col-md-6">
                        <label for="venue" class="form-label">Venue *</label>
                        <input type="text" class="form-control" id="venue"
                               name="venue" maxlength="255"
                               value="<?= e($venue) ?>" required>
                    </div>

                    <div class="col-md-6">
                        <label for="organizer" class="form-label">Organizer *</label>
                        <input type="text" class="form-control" id="organizer"
                               name="organizer" maxlength="150"
                               value="<?= e($organizer) ?>" required>
                    </div>

                    <div class="col-md-6">
                        <label for="registration_open" class="form-label">Registration</label>
                        <select class="form-select" id="registration_open" name="registration_open">
                            <option value="1" <?= $registrationOpen === '1' ? 'selected' : '' ?>>Open</option>
                            <option value="0" <?= $registrationOpen === '0' ? 'selected' : '' ?>>Closed</option>
                        </select>
                    </div>

                    <div class="col-md-6">
                        <label for="is_active" class="form-label">Event Status</label>
                        <select class="form-select" id="is_active" name="is_active">
                            <option value="1" <?= $isActive === '1' ? 'selected' : '' ?>>Active</option>
                            <option value="0" <?= $isActive === '0' ? 'selected' : '' ?>>Inactive</option>
                        </select>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary mt-4">
                    Create Event
                </button>
            </form>
        </div>
    </div>

    <div class="card page-card shadow-sm">
        <div class="card-header bg-white py-3">
            <h2 class="h5 mb-0">Existing Events (<?= count($events) ?>)</h2>
        </div>
        <div class="card-body">
            <?php if (!$events): ?>
                <p class="text-muted mb-0">No events have been created yet.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead>
                        <tr>
                            <th>Event</th>
                            <th>Date and Time</th>
                            <th>Venue</th>
                            <th>Capacity</th>
                            <th>Registration</th>
                            <th>Active</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($events as $event): ?>
                            <tr>
                                <td>
                                    <strong><?= e($event['title']) ?></strong>
                                    <div class="small text-muted"><?= e($event['organizer']) ?></div>
                                </td>
                                <td>
                                    <?= e(date('M d, Y', strtotime($event['event_date']))) ?>
                                    <div class="small text-muted">
                                        <?= e(substr((string) $event['start_time'], 0, 5)) ?>
                                        – <?= e(substr((string) $event['end_time'], 0, 5)) ?>
                                    </div>
                                </td>
                                <td><?= e($event['venue']) ?></td>
                                <td><?= (int) $event['max_attendees'] ?></td>
                                <td>
                                    <?php if ((int) $event['registration_open'] === 1): ?>
                                        <span class="badge text-bg-success">Open</span>
                                    <?php else: ?>
                                        <span class="badge text-bg-secondary">Closed</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if ((int) $event['is_active'] === 1): ?>
                                        <span class="badge text-bg-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge text-bg-danger">Inactive</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
</body>
</html>
